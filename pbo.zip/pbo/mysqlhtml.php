<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Database </title>
</head>
<body>
	<h1> Database Siswa </h1>
	<table border="1" cellpadding="10" cellspacing="0"> 
		<tr>
			<th> No Induk </th>
			<th> Nama Siswa </th>
			<th> Alamat </th>
			<th> No Handphone </th>
		</tr>
		<?php  
		include "mysqlclass.php";
		$no = 1
		$query = mysqli_master_query(
			$koneksi, 'SELECT * FROM' datasiswa)





		?>




	</table>

</body>
</html>