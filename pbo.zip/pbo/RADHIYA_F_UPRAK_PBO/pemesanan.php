<?php

include 'koneksiclass_pemesanan.php';

$data_pemesanan = $db->readPemesanan();

?>

<!DOCTYPE html>
<html>
<head>
	<title>pemesanan</title>
</head>
<body>
	<h3 align="center">Data Pemesanan Food Corner BPI</h3>
	<center> 
		<form action="koneksiclass_pemesanan.php" method="POST">
			<table>
				<td>Nama Makanan</td>
					<td>: <input type="text" name="nama_makanan"></td>
				</tr>
				<tr>
					<td>Harga</td>
					<td>: <input type="text" name="harga"></td>
				</tr>
				<tr>
					<td>Waktu Pesan</td>
					<td>: <input type="datetime-local" name="waktu_pesan"></td>
				</tr>
				<tr>
					<td>Jumlah Pesanan</td>
					<td>: <input type="number" name="jumlah_pesanan"></td>
				</tr>
				<tr>
					<td colspan="2" align="right">
						<input type="submit" name="submitPemesanan" value="SUBMIT"></td>
				</tr>

	<table border="1" cellpadding="5px" align="center">
		<br><br><br>
		<tr>
			<th>No</th>
			<th>Nama Makanan</th>
			<th>Harga</th>
			<th>Waktu Pesan</th>
			<th>Jumlah Pesanan</th>
			<th colspan="2">Action</th>
		</tr>
		<?php 
			$i = 1; 
			foreach ($data_pemesanan as $data) { 
				$id = $data['id_pemesanan'];
		?>

		<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_makanan']; ?></td>
				<td><?php echo $data['harga']; ?></td>
				<td><?php echo $data['waktu_pesan']; ?></td>
				<td><?php echo $data['jumlah_pesanan']; ?></td>
				<td><a href=<?php echo "update_pemesanan.php?aksi=update&id=$id"?>>Edit</a>
				<td><a href=<?php echo "koneksiclass_pemesanan.php?aksi=hapus&id=$id"?>>Delete</a>
                </td>
		</tr>
		<?php	
			$i++; }
		?>
	</table>
	<!-- <center><a href="insert_pemesanan.php" id="insertPemesanan">Tambah Data Pemesanan</a></center> -->
	
</body>
</html>
				