<?php

class database{
	//properti
	private $dbHost="localhost";
	private $dbUser="root";
	private $dbPass="";
	private $dbName="db_pemesanan";

	function connectMySQL(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		if(!$koneksi){
			 die("Koneksi ke DB gagal: " . mysqli_connect_error());
		}else{
	
		}
	} 

	function readPemesanan(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);

		$query = mysqli_query($koneksi, "SELECT * FROM tb_pemesanan");
		
		while($row=mysqli_fetch_array($query)){
			$data[]=$row;
		}
		return $data;
	}

	function insertPemesanan($nama_makanan, $harga, $waktu_pesan, $jumlah_pesanan){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		
		$query = mysqli_query($koneksi, "INSERT INTO tb_pemesanan (nama_makanan, harga, waktu_pesan, jumlah_pesanan) VALUES('$nama_makanan', 'harga', 'waktu_pesan', 'jumlah_pesanan')");
		
		if($query){
			echo "Data Berhasil Ditambahkan";
			header('location:pemesanan.php');
		}else{
			echo "Penambahan Data Gagal";
		}
	} 

	function hapusPemesanan($id){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		//var penampung nilai boolean dari hasil method query SQL
		$query = mysqli_query($koneksi, "DELETE FROM tb_pemesanan WHERE id_pemesanan =".$id."");
		
		if($query){
			echo "Data Berhasil Dihapus";
			header('location:pemesanan.php');
		}else{
			echo "Data Gagal Dihapus";
		}
	}

	function getPemesananById($field, $id){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "SELECT * FROM tb_pemesanan WHERE id_pemesanan =".$id."");
		$data = mysqli_fetch_array($query);
		
		if ($field == 'id_pemesanan'){
			return $data['id_pemesanan'];
		}else if($field == 'nama_makanan'){
			return $data['nama_makanan'];
		}else if($field == 'harga'){
			return $data['harga'];
		}else if($field == 'waktu_pesan'){
			return $data['waktu_pesan'];
		}else if($field == 'jumlah_pesanan'){
			return $data['jumlah_pesanan'];
		}
	}

	function updateDataPemesanan($id, $nama_makanan, $harga, $waktu_pesan, $jumlah_pesanan){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "UPDATE tb_pemesanan SET nama_makanan ='$nama_makanan', harga ='$harga', waktu_pesan ='$waktu_pesan', jumlah_pesanan ='$jumlah_pesanan' WHERE id_pemesanan ='$id'");

		if($query){ 
			echo "Data Berhasil Diupdate";
			header('location:pemesanan.php');
		}else{
			echo "Data Gagal Diupdate";
		}
	}
}

$db = new database();

$db->connectMySQL();
$db->readPemesanan();

if(isset($_POST['submitPemesanan'])){ 
	//variabel baru
	$nama_makanan=$_POST['nama_makanan']; 
	$harga=$_POST['harga'];
	$waktu_pesan=$_POST['waktu_pesan'];	
	$jumlah_pesanan=$_POST['jumlah_pesanan'];

	$db->insertPemesanan($nama_makanan, $harga, $waktu_pesan, $jumlah_pesanan);

}else if(isset($_POST['prosesUpdate'])){
		$id=$_POST['id_pemesanan'];
		$nama_makanan=$_POST['nama_makanan'];
		$harga=$_POST['harga'];
	    $waktu_pesan=$_POST['waktu_pesan'];	
	    $jumlah_pesanan=$_POST['jumlah_pesanan'];

		$db->updateDataPemesanan($id, $nama_makanan, $harga, $waktu_pesan, $jumlah_pesanan);
}

if(isset($_GET['aksi'])){ 

	if($_GET['aksi'] == 'hapus'){
		$id=$_GET['id'];
		$db->hapusPemesanan($id);

	}else if($_GET['aksi'] == 'update'){
		$id=$_GET['id']; 	
	}
}

?>