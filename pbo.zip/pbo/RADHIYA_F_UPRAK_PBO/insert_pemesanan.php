<html>
	<body>
		<form action="koneksiclass_pemesanan.php" method="POST">
			<table>
				<tr>
					<td>Nama Makanan</td>
					<td>:<input type="text" name="nama_makanan"></td>
				</tr>
				<tr>
					<td>Harga</td>
					<td>:<input type="text" name="harga"></td>
				</tr>
				<tr>
					<td>Waktu Pesan</td>
					<td>:<input type="datetime-local" name="waktu_pesan"></td>
				</tr>
				<tr>
					<td>Jumlah Pesanan</td>
					<td>:<input type="number" name="jumlah_pesanan"></td>
				</tr>
				<tr>
					<!-- <td colspan="2" align="right"><input type="submit" name="submitPemesanan" value="SIMPAN"/></td> -->
				</tr>
			</table>
		</form>
	</body>
	<!-- <a href="pemesanan.php">Home</a> -->
</html>