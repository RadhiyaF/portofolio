<?php
 include 'koneksiclass_pemesanan.php';
 ?>

 <html>
    <body>
        <form action="koneksiclass_pemesanan.php" method="POST">
            <input type="hidden" name="id_pemesanan" value="<?php echo $id; ?>">
            <table>
                <tr>
                    <td>Nama Makanan</td>
                    <td>:<input type="text" name="nama_makanan" value="<?php echo $db->getPemesananById('nama_makanan', $id); ?>"></td>
                </tr>
                <tr>
                    <td>Harga</td>
                    <td>:<input type="text" name="harga" value="<?php echo $db->getPemesananById('harga', $id); ?>"></td>
                </tr>
                <tr>
                    <td>Waktu Pemesanan</td>
                    <td>:<input type="datetime-local" name="waktu_pemesanan" value="<?php echo $db->getPemesananById('waktu_pemesanan', $id); ?>"></td>
                </tr>
                 <tr>
                    <td>Jumlah Pesanan</td>
                    <td>:<input type="number" name="jumlah_pesanan" value="<?php echo $db->getPemesananById('jumlah_pesanan', $id); ?>"></td>
                </tr>
                <tr>
                    <td colspan="2" align="right"><input type="submit" name="prosesUpdate" value="UBAH"></td>
                </tr>
            </table>
        </form>
    </body>
 <a href="pemesanan.php">Home</a>
</html>