<?php  

class Siswa{
//properties
	public $nis;
	public $nama;
	

//construct
	function __construct ($param_nis, $param_nama, $param_jabatan){
		$this->nis = $param_nis;
		$this->nama = $param_nama;
}   		
}

class osis extends Siswa{
    public $jabatan;

public function __construct ($param_nis, $param_nama, $param_jabatan){
		$this->nis = $param_nis;
		$this->nama = $param_nama;
		$this->jabatan = $param_jabatan;
}   		
    public function intro (){
    	echo "Hallo, saya {$this->nama} adalah {$this->jabatan}";


    }
}
  
  //membuat objek 
$osis1 = new osis ("222310001", "Alvin", "Ketua OSIS");
  //cetak
        //echo "Siswa 1 <br>";
		echo "Data OSIS <br>:"; 
		echo "NIS" . $osis1->nis;
		echo "<br>";
		echo "Nama:" . $osis1->nama;
	    echo "<br>";
		echo "Jabatan:" . $osis1->jabatan;
		echo "<br><br>";
		$osis1->intro(); //memanggil fungsi intro di kelas OSIS
 



//fungsi mengambil isi variable nis
		//function get_nis(){
			//return $this->nis;}
//fungsi mengambil isi variable nama
		//function get_nama(){
			//return $this->nama;}
//fungsi mengambil isi variable nilai
		//function get_nilai(){
			//return $this->nilai;}

//membuat objek
		//$siswa1 = new Siswa("151610001", "Albana", 90);
		//$siswa2 = new Siswa("151610002", "Albini", 85);
		//$siswa3 = new Siswa("151610003", "Albono", 95);

//mencetak isi properti
		//echo "Siswa 1 <br>";
		//echo "NIS:" . $siswa1->nis;
		//echo "<br>";
		//echo "<br>";
		//echo "Nama:" . $siswa1->nama;
		//echo "<br>";
		//echo "Nilai:" . $siswa1->nilai;
		//echo "<br><br>";

		//echo "Siswa 2 <br>";
		//echo "NIS:" . $siswa2->nis;
		//echo "<br>";
		//echo "Nama:" . $siswa2->nama;
		//echo "<br>";
		//echo "Nilai:" . $siswa2->nilai;
		//echo "<br><br>";

		//echo "Siswa 3 <br>";
		//echo "NIS:" . $siswa3->nis;
		//echo "<br>";
		//echo "Nama:" . $siswa3->nama;
		//echo "<br>";
		//echo "Nilai:" . $siswa3->nilai;
		//echo "<br>";

	?>