<?php 

class database{
	//properti
	private $dbHost="localhost";
	private $dbUser="root";
	private $dbPass="";
	private $dbName="datab_perpus";

	//method koneksi MySQL
	function connectMySQL(){
		$koneksi = mysqli_connect($this->dbHost,$this->dbUser,$this->dbPass,$this->dbName);
		if(!$koneksi){
			die("Koneksi ke DB gagal:" . mysqli_error());
		} else {
			//echo "Koneksi ke DB {$this->dbName} Berhasil";
		} 
	} 

	function readAnggota(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "SELECT * FROM tb_anggota");
		while($row=mysqli_fetch_array($query)){
			$data[]=$row;
		}
		return $data;
	}
	  function insertAnggota($nama){
	  	$koneksi = mysqli_connect($this->dbHost,$this->dbUser,$this->dbPass,$this->dbName);

	  	$query = mysqli_query($koneksi, "INSERT INTO tb_anggota(Nama_anggota) VALUES('$nama')");

	  	IF($query){//jika query berhasil dilaksanakan
	  		echo "Data Berhasil Ditambahkan";
	  		header('location:datab_perpus.php');//kembali ke halaman tampil data
	  	} else{
	  		echo "Penambahan Data Gagal";
	  	}
	  } //penutup insert function

	  function hapusAnggota($id){
	  	$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);

	  	$query = mysqli_query($koneksi,"DELETE FROM tb_anggota WHERE Id_anggota =".$id."");

	  	if($query){
	  		echo "Data Berhasil Dihapus";
	  		header ('location:datab_perpus.php');
	  	} else {
	  		echo "Data Gagal Dihapus";
	  	}
	  }

function getAnggotaById($field, $id){
	$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
	$query = mysqli_query($koneksi, "SELECT * FROM tb_anggota WHERE Id_anggota = ".$id."");
	$data = mysqli_fetch_array($query);

	if ($field == 'Id_anggota') {
		return $data['Id_anggota'];
	} else if($field == 'Nama_anggota'){
		return $data['Nama_anggota'];
	}
  }

 function updateDataAnggota($id, $nama){
 	$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
 	$query = mysqli_query($koneksi, "UPDATE tb_anggota SET Nama_anggota = '$nama' WHERE Id_anggota = '$id'");

 	if($query){
 		echo "Data Berhasil Diupdate";
 		header('location:datab_perpus.php');
 	} else {
 		echo "Data Gagal Diupdate";
 	}
 }
}
$db = new database();
$db->connectMySQL();

if (isset($_POST['submitAnggota'])){
	$nama=$_POST['namaAnggota'];
	$db->insertAnggota($nama);
} else if (isset($_POST['prosesUpdate'])){
	$id = $_POST['Id_anggota'];
	$nama = $_POST['Nama_anggota'];

	$db->updateDataAnggota($id, $nama);
}

if (isset($_GET['aksi'])){
	if(($_GET['aksi'])=='hapus'){
		$id=$_GET['id'];

		$db->hapusAnggota($id);

	} else if($_GET['aksi'] == 'update'){
		$id = $_GET['id'];
	}
}
?>