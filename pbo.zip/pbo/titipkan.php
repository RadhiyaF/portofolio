<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> titipkan </title>
</head>
<body style="background-color: mediumturquoise;">
	<form method="POST" action="">
		<h1> PENITIPAN HEWAN </h1>
		<table>
			<tr>
				<td> Nama Pemilik </td>
				<td> : <input type="text" value="<?php echo $_GET['nama']?>"></td>
			</tr>
			<tr>
				<td> No Pemilik </td>
				<td> : <input type="text" value="<?php echo $_GET['no']?>"></td>
			</tr>
			<tr>
				<td> Nama Hewan </td>
				<td> : <input type="text" name="jenisnya" value="<?php echo $_GET['jenis']?>"></td>
			</tr>
			<tr>
				<td> Ciri Hewan </td>
				<td> : <input type="text" value="<?php echo $_GET['ciri']?>"></td>
			</tr>
			<tr>
				<td> Lama Penitipan (per hari) </td>
				<td> : <input type="text" name="lama"></td>
			</tr>
			<tr>
				<td></td>
				<td> &nbsp;&nbsp; <input type="submit" value="Simpan"></td>
			</tr>
		</table>
</form>
</body>
</html>
<?php

if ($_POST) {
	$lama=$_POST['lama'];
	$jenis=$_POST['jenisnya'];
	$total=100000 * intval ($lama);
	echo "Anda menitipkan " . $jenis . " ini selama" . $lama. " dengan biaya penitipan perharinya Rp. 100.000. <br>" . " total menjadi" .$total;
}
?>
