<?php
$servername = "localhost";
$database = "Siswa";
$username = "root";
$password = "";
// Create connection
$conn = mysql_connect($servername, $username, $password, $database)
// Check connection
if (!$conn) {
	die("Connection failed: " . mysql_connect_error())
}
echo "Connected successfully";
mysql_close($conn);
?>