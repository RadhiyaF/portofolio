<?php
	include 'Koneksi_class.php';
?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Update Anggota </title>
</head>
<body>
	<form action="Koneksi_class.php" method="POST">
		<input type="hidden" name="Id_anggota" value="<?php echo $id;?>">
		<table>
			<tr>
		         <td> Nama Anggota </td>
		         <td>  : <input type="text"  name="Nama_anggota" value="<?php echo $db->getAnggotaById('Nama_anggota', $id);?>"> </td>
		    </tr>
		    <tr>
		    	<td colspan="2" align="right"><input type="submit" name="prosesUpdate" value="UBAH"/></td>
		    </tr>
		</table>
    </form>
<a href="datab_perpus.php"> Home </a>
</body>
</html>