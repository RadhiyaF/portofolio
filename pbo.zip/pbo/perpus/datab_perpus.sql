-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2022 at 08:11 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `datab_perpus`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_anggota`
--

CREATE TABLE `tb_anggota` (
  `Id_anggota` int(10) NOT NULL,
  `Nama_anggota` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_anggota`
--

INSERT INTO `tb_anggota` (`Id_anggota`, `Nama_anggota`) VALUES
(2, 'Syafa '),
(3, 'Udin Baharudin');

-- --------------------------------------------------------

--
-- Table structure for table `tb_buku`
--

CREATE TABLE `tb_buku` (
  `Id_buku` int(10) NOT NULL,
  `Judul_buku` varchar(30) NOT NULL,
  `Pengarang` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_buku`
--

INSERT INTO `tb_buku` (`Id_buku`, `Judul_buku`, `Pengarang`) VALUES
(1, 'Harry Potter: Death Hallows', 'J. K. Rowling'),
(2, 'Emma', 'Jane Austen'),
(3, 'Jane Eyre', 'Charlotte Bronte'),
(4, 'Anne of Green Gables', 'L.M. Montgomery'),
(5, 'To Kill a Mockingbird', 'Harper Lee');

-- --------------------------------------------------------

--
-- Table structure for table `tb_petugas_perpus`
--

CREATE TABLE `tb_petugas_perpus` (
  `Id_petugas` int(10) NOT NULL,
  `Nama_petugas` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_petugas_perpus`
--

INSERT INTO `tb_petugas_perpus` (`Id_petugas`, `Nama_petugas`) VALUES
(11, 'Diva Andini'),
(22, 'Dimas Hamzah'),
(33, 'Ranti Prita'),
(44, 'Lintang Ibra'),
(55, 'Janice Kim');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pinjam_buku`
--

CREATE TABLE `tb_pinjam_buku` (
  `Id_pinjam` int(11) NOT NULL,
  `Id_buku` int(11) NOT NULL,
  `Id_petugas` int(11) NOT NULL,
  `Id_anggota` int(11) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  ADD PRIMARY KEY (`Id_anggota`);

--
-- Indexes for table `tb_buku`
--
ALTER TABLE `tb_buku`
  ADD PRIMARY KEY (`Id_buku`);

--
-- Indexes for table `tb_petugas_perpus`
--
ALTER TABLE `tb_petugas_perpus`
  ADD PRIMARY KEY (`Id_petugas`);

--
-- Indexes for table `tb_pinjam_buku`
--
ALTER TABLE `tb_pinjam_buku`
  ADD PRIMARY KEY (`Id_pinjam`),
  ADD KEY `Id_petugas` (`Id_petugas`),
  ADD KEY `Id_buku` (`Id_buku`),
  ADD KEY `Id_anggota` (`Id_anggota`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_anggota`
--
ALTER TABLE `tb_anggota`
  MODIFY `Id_anggota` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_pinjam_buku`
--
ALTER TABLE `tb_pinjam_buku`
  ADD CONSTRAINT `tb_pinjam_buku_ibfk_2` FOREIGN KEY (`Id_petugas`) REFERENCES `tb_petugas_perpus` (`Id_petugas`),
  ADD CONSTRAINT `tb_pinjam_buku_ibfk_3` FOREIGN KEY (`Id_buku`) REFERENCES `tb_buku` (`Id_buku`),
  ADD CONSTRAINT `tb_pinjam_buku_ibfk_4` FOREIGN KEY (`Id_anggota`) REFERENCES `tb_anggota` (`Id_anggota`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
