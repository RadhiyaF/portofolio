<?php
//memanggil file koneksi
include 'koneksiclassSupermarket.php';

//buat array data anggota dari method readBarang di class databse

$data_barang = $db->readBarang();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Database </title>
</head>
<body>
	<h3 align="center"> Data Barang Supermarket </h3>
	<table border = "1" cellpadding="5px" align="center">
		<tr>
			<th>No</th>
			<th>Nama Barang</th>
			<th>Total Barang</th>
			<th>Harga Barang</th>
			<th colspan="2">Tindakan</th>
		</tr>
		<?php 
		$i = 1;
		foreach ($data_barang as $data){
			$id = $data['Id_barang'];
		?>
		<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $data['Nama_barang']; ?></td>
				<td><a href=<?php echo "update_barang.php?aksi=update&id=$id"?>>Edit</a></td>
				<td><a href=<?php echo "koneksiclassSupermarket.php?aksi=hapus&id=$id"?>>Delete</a>
				</td>
			</tr>
		<?php	
			$i++; }
		?>
	</table>
<center><a href="insert_barang.php" id="insertBarang">Tambah Data Barang</a></center>

</body>
</html>