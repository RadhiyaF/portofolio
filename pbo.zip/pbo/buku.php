<?php  

class buku{
	//properties
	public $nama;
	public $jenis;
	public $tahun_terbit;

//construct
	function __construct ($pr_nama, $pr_jenis, $pr_tahun_terbit){
		$this->nama = $pr_nama;
		$this->jenis = $pr_jenis;
		$this->tahun_terbit = $pr_tahun_terbit;  
     }
 }

 class ebook extends buku{
 	public $url;

 	public function __construct ($pr_nama, $pr_jenis, $pr_tahun_terbit, $url){
		$this->nama = $pr_nama;
		$this->jenis = $pr_jenis;
		$this->tahun_terbit = $pr_tahun_terbit;
		$this->url = $url;
  }


  public function deskripsi (){
    	echo "Link E-book {$this->nama} adalah {$this->url}";
      
}
}

class jurnal extends ebook{
 	public $author;

 	public function __construct ($pr_nama, $url, $author){
		$this->nama = $pr_nama;
		$this->url = $url;
		$this->author = $author;
}

  public function deskripsi (){
    	echo "Link Jurnal {$this->nama} adalah {$this->url}";
      }
}



//membuat objek 
$buku1 = new ebook ("Eggnoid", "Romance", "13 Desember 2015", "1234567891011");
$jurnal1 = new jurnal ("Pengembangan AI di yayasan BPI", "10987654321","Nur Hayanti");
  //cetak
        echo "E-book <br>"; 
		    echo "Nama: " . $buku1->nama;
		    echo "<br>";
		    echo "Jenis:" . $buku1->jenis;
	      echo "<br>";
		    echo "Tahun terbit:" . $buku1->tahun_terbit;
		    echo "<br><br>";
		    $buku1->deskripsi(); //memanggil fungsi intro di kelas OSIS

echo "<br><br>";
        echo "2<br>";
        echo "Nama jurnal:" . $jurnal1->nama;
        echo "<br>";
         echo "Nama author:" . $jurnal1->author;
        echo "<br>";
        $jurnal1->deskripsi();
?>