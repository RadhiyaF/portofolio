<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Halaman 1 </title>
</head>
<body style="background-color: #b3b3ff;">
	<form action="halaman2.php" method="get">
		Nama: <input type="text" name="inputNama"><br>
		Genre: <input type="text" name="inputJenis"><br>
		Tahun Terbit: <input type="text" name="inputTahunTerbit"><br>
		<input type="submit" name="submit">
	</form>

</body>
</html>