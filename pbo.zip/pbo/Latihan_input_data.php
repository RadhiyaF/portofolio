<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Latihan Input Data </title>
</head>
<body style="background-color: bisque;">
	<form action="LID.php" method="get">
		Nama Siswa: <input type="text" name="inputNamaSiswa"><br>
		Tanggal Lahir: <input type="text" name="inputTanggalLahir"><br>
		Alamat: <input type="text" name="inputAlamat"><br>
		Agama: <input type="text" name="inputAgama"><br>
		Asal Sekolah: <input type="text" name="inputAsalSekolah"><br>
		<input type="submit" name="submit">

</body>
</html>