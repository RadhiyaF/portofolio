<?php
//memanggil file koneksi
include 'Koneksi_class.php';

//buat array data anggota dari method readAnggota di class database
$data_anggota = $db->readAnggota();

?>

<!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<title> DB </title>


 </head>
 <body>
       <h3 align="center"> Data Anggota Perpustakaan </h3>
       <table border="1" cellpadding="5px" align="center">
       	<tr>
       		<th> No </th>
       		<th> Nama </th>
                  <th> Action </th>
       	</tr>
       	<?php 
       	$i = 1;
       	foreach ($data_anggota as $data){
                  $id = $data['Id_anggota'];
       		?>
       		<tr>
       			<td><?php echo $i; ?></td>
       			<td><?php echo $data['Nama_anggota']; ?></td>
                        <td> <a href =<?php echo "updateAnggota.php?aksi=update&id=$id"?>> Edit </a></td>
                        <td> <a href=<?php echo "Koneksi_class.php?aksi=hapus&id=$id"?>> Delete </a></td>
       		</tr>
       		<?php 
       		$i++;}
       		?>
       		<tr></tr>
       </table>
       <center><a href="insert_anggota.php" > Tambah Data Anggota </a>
 </body>
 </html> 