<html>
	<body>
		<form action="koneksiclassSupermarket.php" method="POST">
			<table>
				<tr>
					<td>Nama Barang</td>
					<td>:<input type="text" name="Nama_barang"></td>
				</tr>
				<tr>
					<td colspan="2" align="right"><input type="submit" name="submitBarang" value="SIMPAN"/></td>
				</tr>
			</table>
		</form>
	</body>
	
	<a href="supermarket.php">Home</a>
</html>