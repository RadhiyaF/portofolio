<?php
//memanggil file koneksi
include 'koneksiclassSupermarket.php';

//buat array data anggota dari method readAnggota di class database
$data_barang = $db->readBarang();
$daftar_pembelian = $db->readPembelian();

?>

<!DOCTYPE html>
<html>
<head>
	<title>DB</title>
</head>
<body>
	<h3 align="center">Data Barang Supermarket</h3>
	<table border="1" cellpadding="5px" align="center">
		<tr>
			<th>No</th>
			<th>Nama_barang</th>
			<th>Total_barang</th>
			<th>Harga</th>
			<th>Total_harga</th>
			<th colspan="2">Tindakan</th>
		</tr>
		<?php 
			$i = 1; 
			foreach ($data_barang as $data) { 
				$id = $data['Id_barang'];
		?>
			<tr>

				<td><?php echo $i; ?></td>
				<td><?php echo $data['Nama_barang']; ?></td>
				<td><?php echo $data['Total_barang']; ?></td>
				<td><?php echo $data['Harga']; ?></td>
                <td><?php echo $data['Total_harga']; ?></td>
				<td><a href=<?php echo "update_supermarket.php?aksi=update&id=$id"?>>Edit</a>
				<td><a href=<?php echo "koneksiclassSupermarket.php?aksi=hapus&id=$id"?>>Delete</a>

	</td>
			</tr>
		<?php	
			$i++; }
		?>
	</table>
	<center><a href="insert_supermarket.php" id="insertBarang">Tambah Data Barang</a></center>
	<br>
	<h3 align="center">Data Pembelian</h3>
	<center> 
		<form action="koneksiclassSupermarket.php" method="POST">
			<table>
				<tr>
					<td>Tanggal Pembelian</td>
					<td>: <input type="date" name="tgl_beli"></td>
				</tr>
				<tr>
					<td>Nama Barang</td>
					<td>: <select name="drop_barang">
						<?php
						foreach ($data_barang as $data) { 
							?>
							<option value="<?php echo $data['Id_barang'];?>">
								<?php echo $data['Nama_barang'];?></option>
						<?php }
						?>
					</select>
				</td>
				</tr>
				<tr>
					<td>Quantity</td>
					<td>: <input type="number" name="qty"></td>
				</tr>
				<tr>
					<td colspan="2" align="right">
						<input type="submit" name="subpembelian" value="KIRIM"></td>
				</tr>
			</table>
		</form>
	</center>
	<table border="1" cellpadding="5px" align="center">
		<tr>
			<th>No</th>
			<th>Tanggal Pembelian</th>
			<th>Nama Barang</th>
			<th>Quantity</th>
		</tr>
		<?php 
			$i = 1; 
			foreach ($daftar_pembelian as $data) { 
				$id = $data['Id_pembelian'];
		?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $data['Tanggal_pembelian']; ?></td>
				<td><?php echo $data['Nama_barang']; ?></td>
				<td><?php echo $data['Quantity']; ?></td>
            </td>
			</tr>
		<?php	
			$i++; }
		?>
	</table>
	<center><a href="insert_pembelian.php" id="insertPembelian">Tambah Data Pembelian</a></center>
</body>
</html>