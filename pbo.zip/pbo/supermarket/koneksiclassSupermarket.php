<?php

class database{
	//properti
	private $dbHost="localhost";
	private $dbUser="root";
	private $dbPass="";
	private $dbName="db_supermarket";
	
	//method koneksi MySQL
	function connectMySQL(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		if(!$koneksi){
			 die("Koneksi ke DB gagal: " . mysqli_connect_error());
		}else{
			// echo "Koneksi ke DB Berhasil";
		}
	} //penutup function connectMySQL

	function readBarang(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);

		$query = mysqli_query($koneksi, "SELECT * FROM tb_barang");
		
		while($row=mysqli_fetch_array($query)){
			$data[]=$row;
		}
		return $data;
	} //penutup function readAnggota 

	//di bawah function readAnggota
	function insertBarang($nama, $Total_barang, $Harga, $Total_harga){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		//var penampung nilai boolean dari hasil method query SQL
		$query = mysqli_query($koneksi, "INSERT INTO tb_barang (Nama_barang, Total_barang, Harga, Total_harga) VALUES('$nama', '$Total_barang', '$Harga', '$Total_harga')");
		
		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Ditambahkan";
			header('location:supermarket.php'); //kembali ke halaman tampil data
		}else{
			echo "Penambahan Data Gagal";
		}
	} //penutup function insertAnggota

	function hapusBarang($id){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		//var penampung nilai boolean dari hasil method query SQL
		$query = mysqli_query($koneksi, "DELETE FROM tb_barang WHERE Id_barang =".$id."");
		
		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Dihapus";
			header('location:supermarket.php'); //kembali ke halaman tampil data
		}else{
			echo "Data Gagal Dihapus";
		}
	}

	function getBarangById($field, $id){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "SELECT * FROM tb_barang WHERE Id_barang =".$id."");
		$data = mysqli_fetch_array($query);
		
		if ($field == 'Id_barang'){
			return $data['Id_barang'];
		}else if($field == 'Nama_barang'){
			return $data['Nama_barang'];
		}else if($field == 'Total_barang'){
			return $data['Total_barang'];
		}else if($field == 'Harga'){
			return $data['Harga'];
		}else if($field == 'Total_harga'){
			return $data['Total_harga'];
		}
	}

	function updateDataBarang($id, $nama, $Total_barang, $Harga, $Total_harga){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "UPDATE tb_barang SET Nama_barang ='$nama', Total_barang = '$Total_barang', Harga = '$harga', Total_harga = '$Total_harga' WHERE Id_barang ='$id'");

		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Diupdate";
			header('location:supermarket.php'); //kembali ke halaman tampil data
		}else{
			echo "Data Gagal Diupdate";
		}
	}
	function readPembelian(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);

		$query = mysqli_query($koneksi, "SELECT * FROM tb_pembelian JOIN tb_barang ON tb_pembelian.Id_barang = tb_barang.Id_barang");

		if($row=mysqli_fetch_array($query) != NULL){

		while($row=mysqli_fetch_array($query)){
			$data[]=$row;
		}
		return $data;
	 }
	} //penutup function readAnggota 

function insertPembelian($tgl, $id, $qty){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		//var penampung nilai boolean dari hasil method query SQL
		$query = mysqli_query($koneksi, "INSERT INTO tb_pembelian (Tanggal_pembelian, Id_barang, Quantity) VALUES( '$Tanggal_pembelian', '$Id_barang', '$Quantity')");
		
		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Ditambahkan";
			header('location:supermarket.php'); //kembali ke halaman tampil data
		}else{
			echo "Penambahan Data Gagal";
		}
	} //penutup function insertAnggota
	

} //penutup class database


//instansiasi objek db
$db = new database();

//koneksi ke MySQL via method di class database
$db->connectMySQL();
$db->readBarang();
$db->readPembelian();

if(isset($_POST['submitBarang'])){ //jika button mengirim data
	//variabel baru
	$nama=$_POST['Nama_barang']; //ambil data dari form
	$Total_barang=$_POST['Total_barang'];
	$Harga=$_POST['Harga'];
	$Total_harga=$_POST['Total_harga'];
		
	$db->insertBarang($nama); //panggil function insert

}else if(isset($_POST['prosesUpdate'])){
		$id = $_POST['Id_barang'];
		$nama = $_POST['Nama_barang'];
		$Total_barang=$_POST['Total_barang'];
	$Harga=$_POST['Harga'];
	$Total_harga=$_POST['Total_harga'];

		$db->updateDataBarang($id, $nama);
}else if(isset($_POST['subpembelian'])){
	$tgl=$_POST['tgl_beli'];
	$id_barang=$_POST['drop_barang'];
	$qty=$_POST['qty'];

	$db->insertPembelian($tgl, $id, $qty)
}

if(isset($_GET['aksi'])){ //ketika dapat parameter aksi dari hyperlink

	if($_GET['aksi'] == 'hapus'){ //jika aksi berisi hapus
		$id=$_GET['id']; //mengambil id dari parameter
		$db->hapusBarang($id); //memanggil fungsi hapus 

	}else if($_GET['aksi'] == 'update'){
		$id=$_GET['id']; //mengambil id dari parameter	
	}
}



?>