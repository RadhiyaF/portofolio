<?php
 include 'koneksiclassSupermarket.php';
 ?>

<html>
	<body>
		<form action="koneksiclassSupermarket.php" method="POST">
			<input type="hidden" name="Id_barang" value="<?php echo $id; ?>">

			<table>
				<tr>
					<td>Nama Barang</td>
					<td>:<input type="text" name="Nama_barang" value="<?php echo $db->getBarangById('Nama_barang', $id); ?>"></td>
				</tr>

				<tr>
					<td>Total Barang</td>
					<td>:<input type="text" name="Total_barang" value="<?php echo $db->getBarangById('Total_barang', $id); ?>"></td>
				</tr>

				<tr>
					<td>Harga</td>
					<td>:<input type="text" name="Harga" value="<?php echo $db->getBarangById('Harga', $id); ?>"></td>
				</tr>

				<tr>
					<td>Total_harga</td>
					<td>:<input type="text" name="Total_harga" value="<?php echo $db->getBarangById('Total_harga', $id); ?>"></td>
				</tr>
				<tr>
					<td colspan="2" align="right"><input type="submit" name="prosesUpdate" value="UBAH"></td>
				</tr>
			</table>
		</form>
	</body>
	
	<a href="supermarket.php">Home</a>
</html>