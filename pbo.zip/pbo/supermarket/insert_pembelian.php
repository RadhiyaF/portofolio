<html>
	<body>
		<form action="koneksiclassSupermarket.php" method="POST">
			<table>
				<tr>
					<td>Pembelian</td>
					<td>:<input type="text" name="pembelian"></td>
				</tr>
				<tr>
					<td colspan="2" align="right"><input type="submit" name="submitPembelian" value="SIMPAN"/></td>
				</tr>
			</table>
		</form>
	</body>
	
	<a href="supermarket.php">Home</a>
</html>