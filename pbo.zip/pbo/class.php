<?php
  
  class Anggota{
      	//properties
      	public $Id;
      	public $Nama;

      	//method
      	public function readData(){
      		//$str = "Nama Anggota {$this->Id} adalah {$this->Nama}"
      		$ytr = "<br>
      		ID: {$this->Id} <br>
      		Nama: {$this->Nama}";
      	}
      	public function insert_data($pr_Id, $pr_Nama){
      		$this->Id = $pr_Id;
      		$this->Nama = $pr_Nama;
      	}
      	public function update_data(){

      	}
      }

      class Pinjam_buku{
      	//properties
      	public $Id;
      	public $Tanggal_Pinjam;
      	public $Id_buku;
      	public $Tanggal_pengembalian;
      	public $Id_petugas;
        public $Id_anggota

      	//method
      	public function readData(){
      		$hre= "<br>
      		ID: {$this->Id} <br>
      		Tanggal_Pinjam: {$this->Tanggal_Pinjam} <br>
      		Id_buku: {$this->Id_buku} <br>
      		Tanggal_pengembalian: {$this->Tanggal_pengembalian} <br>
      		Id_petugas: {$this->Id_petugas} <br>
          Id_anggota: {$this->Id_anggota} <br>";

      		return $hre;
      	}
      	public function insert_data($pr_Id1, $pr_Tpm, $pr_IdB, $pr_Tpn, $pr_IdP, $pr_IdA){
      		$this->Id = $pr_Id1;
      		$this->Tanggal_Pinjam = $pr_Tpm;
      		$this->Id_buku = $pr_Id1;
      		$this->Tanggal_pengembalian = $pr_Tpn;
      		$this->Id_petugas = $pr_IdP;
          $this->Id_anggota = $pr_IdA;
      	}
      	public function update_data(){

      	}
      	public function pilih_buku(){

      	}
      }

      class petugas_perpus{
      	//properties
      	public $Id_petugas;
      	public $Nama;

      	//method
      	public function insert_data(){

      	}
      	public function update_data(){

      	}
      }

      class buku{
      	//properties
      	public $Id_buku;
      	public $Judul_buku;
      	public $pengarang;

      	//method
      	public function insert_data(){

      	}
      	public function update_data(){

      	}
      }

      class buku_asing extends buku{
      	public $Id_buku;
      	public $Judul_buku;
      	public $pengarang;

      	//method
      	public function insert_data(){

      	}
      	public function update_data(){

      	}
      }

      class buku_lokal extends buku{
      	public $Id_buku;
      	public $Judul_buku;
      	public $pengarang;

      	//method
      	public function insert_data(){

      	}
      	public function update_data(){

      	}
      }

























?>  



?>