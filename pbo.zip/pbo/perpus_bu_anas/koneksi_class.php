<?php

class database{
	//properti
	private $dbHost="localhost";
	private $dbUser="root";
	private $dbPass="";
	private $dbName="db_perpus";
	
	//method koneksi MySQL
	function connectMySQL(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		if(!$koneksi){
			 die("Koneksi ke DB gagal: " . mysqli_connect_error());
		}else{
			// echo "Koneksi ke DB Berhasil";
		}
	} //penutup function connectMySQL

	function readAnggota(){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);

		$query = mysqli_query($koneksi, "SELECT * FROM tb_anggota");
		
		while($row=mysqli_fetch_array($query)){
			$data[]=$row;
		}
		return $data;
	} //penutup function readAnggota 

	//di bawah function readAnggota
	function insertAnggota($nama){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		//var penampung nilai boolean dari hasil method query SQL
		$query = mysqli_query($koneksi, "INSERT INTO tb_anggota (nama_anggota) VALUES('$nama')");
		
		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Ditambahkan";
			header('location:perpus.php'); //kembali ke halaman tampil data
		}else{
			echo "Penambahan Data Gagal";
		}
	} //penutup function insertAnggota

	function hapusAnggota($id){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		//var penampung nilai boolean dari hasil method query SQL
		$query = mysqli_query($koneksi, "DELETE FROM tb_anggota WHERE id_anggota =".$id."");
		
		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Dihapus";
			header('location:perpus.php'); //kembali ke halaman tampil data
		}else{
			echo "Data Gagal Dihapus";
		}
	}

	function getAnggotaById($field, $id){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "SELECT * FROM tb_anggota WHERE id_anggota =".$id."");
		$data = mysqli_fetch_array($query);
		
		if ($field == 'id_anggota'){
			return $data['id_anggota'];
		}else if($field == 'nama_anggota'){
			return $data['nama_anggota'];
		}
	}

	function updateDataAnggota($id, $nama){
		$koneksi = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPass, $this->dbName);
		$query = mysqli_query($koneksi, "UPDATE tb_anggota SET nama_anggota ='$nama' WHERE id_anggota ='$id'");

		if($query){ //jika queri berhasil dijalankan
			echo "Data Berhasil Diupdate";
			header('location:perpus.php'); //kembali ke halaman tampil data
		}else{
			echo "Data Gagal Diupdate";
		}
	}

} //penutup class database


//instansiasi objek db
$db = new database();

//koneksi ke MySQL via method di class database
$db->connectMySQL();

if(isset($_POST['submitAnggota'])){ //jika button mengirim data
	//variabel baru
	$nama=$_POST['nama_anggota']; //ambil data dari form
		
	$db->insertAnggota($nama); //panggil function insert

}else if(isset($_POST['prosesUpdate'])){
		$id = $_POST['id_anggota'];
		$nama = $_POST['nama_anggota'];

		$db->updateDataAnggota($id, $nama);
}

if(isset($_GET['aksi'])){ //ketika dapat parameter aksi dari hyperlink

	if($_GET['aksi'] == 'hapus'){ //jika aksi berisi hapus
		$id=$_GET['id']; //mengambil id dari parameter
		$db->hapusAnggota($id); //memanggil fungsi hapus 

	}else if($_GET['aksi'] == 'update'){
		$id=$_GET['id']; //mengambil id dari parameter	
	}
}



?>