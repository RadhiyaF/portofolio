<?php
//memanggil file koneksi
include 'koneksi_class.php';

//buat array data anggota dari method readAnggota di class database
$data_anggota = $db->readAnggota();

?>

<!DOCTYPE html>
<html>
<head>
	<title>DB</title>
</head>
<body>
	<h3 align="center">Data Anggota Perpustakaan</h3>
	<table border="1" cellpadding="5px" align="center">
		<tr>
			<th>No</th>
			<th>Nama</th>
			<th colspan="2">Action</th>
		</tr>
		<?php 
			$i = 1; 
			foreach ($data_anggota as $data) { 
				$id = $data['id_anggota'];
		?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_anggota']; ?></td>
				<td><a href=<?php echo "update_anggota.php?aksi=update&id=$id"?>>Edit</a>
				<td><a href=<?php echo "koneksi_class.php?aksi=hapus&id=$id"?>>Delete</a>

				</td>
			</tr>
		<?php	
			$i++; }
		?>
	</table>
	<center><a href="insert_anggota.php" id="insertAnggota">Tambah Data Anggota</a></center>

</body>
</html>