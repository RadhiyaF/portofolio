<?php
 include 'koneksi_class.php';
 ?>

<html>
	<body>
		<form action="koneksi_class.php" method="POST">
			<input type="hidden" name="id_anggota" value="<?php echo $id; ?>">

			<table>
				<tr>
					<td>Nama Anggota</td>
					<td>:<input type="text" name="nama_anggota" value="<?php echo $db->getAnggotaById('nama_anggota', $id); ?>"></td>
				</tr>
				<tr>
					<td colspan="2" align="right"><input type="submit" name="prosesUpdate" value="UBAH"></td>
				</tr>
			</table>
		</form>
	</body>
	
	<a href="perpus.php">Home</a>
</html>