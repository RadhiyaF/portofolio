<html>
	<body>
		<form action="koneksi_class.php" method="POST">
			<table>
				<tr>
					<td>Nama Anggota</td>
					<td>:<input type="text" name="nama_anggota"></td>
				</tr>
				<tr>
					<td colspan="2" align="right"><input type="submit" name="submitAnggota" value="SIMPAN"/></td>
				</tr>
			</table>
		</form>
	</body>
	
	<a href="perpus.php">Home</a>
</html>