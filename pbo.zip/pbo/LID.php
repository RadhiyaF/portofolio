<?php  

class biodata {
	//properties
	public $nama_siswa;
	public $tanggal_lahir;
	public $alamat;
	public $agama;
	public $asal_sekolah;

	//construct : menginisialisasi properti
	function __construct ($pr_namasiswa, $pr_tglahir, $pr_alamat, $pr_agama, $pr_asalsk){
		$this->nama_siswa = $pr_namasiswa;
		$this->tanggal_lahir = $pr_tglahir;
		$this->alamat = $pr_alamat;
		$this->agama = $pr_agama;
		$this->asal_sekolah = $pr_asalsk;
     }
}

if ($_GET){
	$inputNamaSiswa = $_GET['inputNamaSiswa'];
	$inputTanggalLahir = $_GET['inputTanggalLahir'];
	$inputAlamat = $_GET['inputAlamat'];
	$inputAgama = $_GET['inputAgama'];
	$inputAsalSekolah = $_GET['inputAsalSekolah'];

$biodata1 = new biodata ($inputNamaSiswa, $inputTanggalLahir, $inputAlamat, $inputAgama, $inputAsalSekolah);

   echo "Biodata Siswa <br>";
   echo "Nama Siswa:" . $biodata1->nama_siswa;
   echo "<br>";
   echo "Tanggal Lahir:" . $biodata1->tanggal_lahir;
   echo "<br>";
   echo "Alamat:" . $biodata1->alamat;
   echo "<br>";
   echo "Agama:" . $biodata1->agama;
   echo "<br>";
   echo "Asal Sekolah:" . $biodata1->asal_sekolah;
   echo "<br>";
}

?>