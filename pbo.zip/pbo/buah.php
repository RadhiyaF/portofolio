<?php  

class buah {
	//propeties
   public $nama;
   public $warna;

    //method
   function set_nama($tampungan_nama){
   	$this->nama = $tampungan_nama;

   }

   function get_nama(){
        return $this->nama;
   }

   function set_warna($tampungan_warna){
   	$this->warna = $tampungan_warna;

   }

    function get_warna(){
        return $this->warna;
   }
}

 //membuat objek
   $pisang = new buah();
   $pisang-> set_nama('Pisang Ambon');
   $pisang-> set_warna ('kuning');

   echo $pisang-> get_nama();
   echo "<br>";
   echo $pisang-> get_warna();
?>