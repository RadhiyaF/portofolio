<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Login </title>
</head>
<body style="background-color: antiquewhite;">
	<form method="GET" action="penitipan.php">
		<h1> LOGIN </h1>
		<table>
		<tr>
			<td> Nama </td>
			<td> : <input type="text" name="nama"></td>
		</tr> 
		<tr>
			<td> No kontak </td>
			<td> : <input type="text" name="no"></td>
		</tr>
		<tr>
			<td> Alamat </td>
			<td> : <input type="text" name="alamat"></td>
		</tr>
		<tr>
			<td>  </td>
			<td> &nbsp;&nbsp;<input type="submit" value="Submit"></td>
		</tr>
		</table>
		<p> Isi dengan benar! </p>
	</form>
</body>
</html>