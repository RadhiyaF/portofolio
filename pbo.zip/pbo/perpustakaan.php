<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> perpustakaan </title>
</head>
<body>
	<form action="perpustakaan.php" method="get">
		<h3> Data Anggota </h3>
		<table>
		<tr>
			<td> ID: </td>
			<td><input type="text" name="inputId" required></td>
		</tr> 
		<tr>
			<td> Nama: </td>
			<td><input type="text" name="inputNama" required></td>
		</tr> 
		</table>

		<h3> Data Pinjam Buku </h3>
		<table>
		<tr>
			<td> ID: </td>
			<td><input type="text" name="inputId1" required></td>
		</tr> 
		<tr>
			<td> Tanggal Pinjam: </td>
			<td><input type="date" name="inputTp" required></td>
		</tr> 
		<tr>
			<td> Id Buku: </td>
			<td><input type="text" name="inputIb" required></td>
		</tr> 
		<tr>
			<td> Tanggal Pengembalian: </td>
			<td><input type="date" name="inputTp1" required></td>
		</tr> 
		<tr>
			<td> Id Petugas: </td>
			<td><input type="text" name="inputIp" required></td>
		</tr> 
	    </table>
	    <input type="submit" name="btnSubmit">
	</form>
</body>
</html>
<?php  

 include 'class.php'

      //objek
      $obj_anggota = new Anggota();
      $obj_pinjam_buku = new Pinjam_buku();
      if($_GET){
      	$Id = $_GET['inputId'];
      	$Nama = $_GET['inputNama'];
      	$Id1 = $_GET['inputId1'];
      	$Tanggal_Pinjam = $_GET['inputTp'];
      	$Id_buku = $_GET['inputIb'];
      	$Tanggal_pengembalian = $_GET['inputTp1'];
      	$Id_petugas = $_GET['inputIp'];

      	$obj_anggota->insert_data($Id, $Nama);
      	echo $obj_anggota->readData();
      	echo "<br>";
      	$obj_pinjam_buku->insert_data($Id1, $Tanggal_Pinjam, $Id_buku, $Tanggal_pengembalian, $Id_petugas);
      	echo $obj_pinjam_buku->readData();
      	echo "<br>";
      }
?>