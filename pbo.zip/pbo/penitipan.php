<?php 
     if($_GET){
     	$nama = $_GET['nama'];
     	$no = $_GET['no'];
     	$alamat = $_GET['alamat'];
     }
?>


<html>
<body style="background-color: whitesmoke;">
	<form method="POST" action="">
	<h1> PENITIPAN HEWAN </h1>
	<table>
		<tr>
			<td> Nama Hewan </td>
			<td> : <input type="text" name="namahewan"></td>
		</tr>
		<tr>
			<td> Jenis Hewan </td>
			<td> : <select name = "jh">
				<option>-</option>
				<option value="Monyet">   Monyet   </option>
				<option value="Anjing">    Anjing    </option>
				<option value="Kura-kura"> Kura-kura </option>
				<option value="Kucing">    Kucing    </option>
				<option value="Burung">    Burung    </option>
			</select></td>
		</tr>
		<tr>
			<td> Ciri-ciri </td>
			<td> : <input type="text" name="cirinya"></td>
		</tr>
		<tr>
			<td> Berat </td>
			<td> : <input type="text" name="berat"></td>
		</tr>
		<tr>
			<td> Usia </td>
			<td> : <input type="text" name="usia"></td>
		</tr>
		<tr>
			<td>  </td>
			<td> &nbsp;&nbsp; <input type="Submit" name="Simpan" value="Simpan"></td>
		</tr>
</table> 
</form>
</body>
</html>

<?php 
if(isset($_POST['Simpan'])){

	class hewan{
		public $namahewan;
		public $jenis;
		public $khusus;
		public $berat;
		public $usia;

		//method
		public function identitas(){
			echo "Nama " . $this->jenis . " : " . $this->namahewan . "<br>";
			echo "Berat " . $this->jenis . " : " . $this->berat . "<br>";
			echo "Usia " . $this->jenis . " : " . $this->usia . "<br>";
			echo "Ciri-ciri : <br> ";
			echo "Ciri-ciri umum hewan yang bisa dititipkan adalah hewan yang 
			      bersuara <br> ";
			echo "Ciri-ciri umum " . $this->jenis . " yaitu ";
		}
	}
 
 interface ciri{
 public function cirikhusus();
 }

 class Monyet extends hewan implements ciri{
 	public function gelantung(){
 		echo "bergelantungan";
 	}
 	public function cirikhusus(){
 		return "Ciri-ciri khusus " . $this->jenis . " yaitu" . $this-> khusus;
 	}
 }

 class Anjing extends hewan implements ciri{
 	public function bark(){
 		echo " menggonggong";
 	}
 	public function cirikhusus(){
 		return " Ciri-ciri khusus" . $this->jenis . " yaitu" . $this-> khusus;
 	}
 }

 class Kurakura extends hewan implements ciri{
 	public function berjalan(){
 		echo " berjalan lambat";
 	}
 	public function cirikhusus(){
 		return " Ciri-ciri khusus " . $this->jenis . " yaitu " . $this-> khusus;
 	}
 }

 class Kucing extends hewan implements ciri{
 	public function meow(){
 		echo "mengeong";
 	}
 	public function cirikhusus(){
 		return " Ciri-ciri khusus" . $this->jenis . " yaitu" . $this-> khusus;
 	}
 }

 class Burung extends hewan implements ciri{
 	public function bersayap(){
 		echo " terbang";
 	}
 	public function cirikhusus(){
 		return " Ciri-ciri khusus " . $this->jenis . " yaitu " . $this-> khusus;
 	}
 }

$sihewan = new hewan;
$sihewan->namahewan = $_POST['namahewan'];
$sihewan->berat = $_POST['berat'];
$sihewan->usia = $_POST['usia'];
$sihewan->khusus = $_POST['cirinya'];
$sihewan->jenis = $_POST['jh'];

echo $sihewan->identitas();

$simonyet = new Monyet;
$simonyet->jenis = $_POST['jh'];
$simonyet->khusus = $_POST['cirinya'];

$sianjing = new Anjing;
$sianjing->jenis = $_POST['jh'];
$sianjing->khusus = $_POST['cirinya'];

$sikurakura = new Kurakura;
$sikurakura->jenis = $_POST['jh'];
$sikurakura->khusus = $_POST['cirinya'];

$sikucing = new Kucing;
$sikucing->jenis = $_POST['jh'];
$sikucing->khusus = $_POST['cirinya'];

$siburung = new Burung;
$siburung->jenis = $_POST['jh'];
$siburung->khusus = $_POST['cirinya'];

$namahewan = $_POST['namahewan'];
$khusus = $_POST['cirinya'];
$jenis = $_POST['jh'];

if($jenis == "Monyet"){
	$simonyet->gelantung();
	echo "<br>";
	echo $simonyet->cirikhusus();
} else if ($jenis == "Anjing"){
	$sianjing->bark();
	echo "<br>";
	echo $sianjing->cirikhusus();
} else if ($jenis == "Kurakura"){
	$sikurakura->berjalan();
	echo "<br>";
	echo $sikurakura->cirikhusus();
} else if ($jenis == "Kucing"){
	$sikucing->meow();
	echo "<br>";
	echo $sikucing->cirikhusus();
} else if ($jenis == "Burung"){
	$siburung->bersayap();
	echo "<br>";
	echo $siburung->cirikhusus();
}

echo "<br><br><a href=\"titipkan.php?nama=$nama&no=$no&namahewan=$namahewan&jenis=$jenis&ciri=$khusus\"> titipkan </a>";
}
?>