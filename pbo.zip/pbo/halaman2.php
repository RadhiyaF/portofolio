<?php  

class buku{
	//properties
	public $nama;
	public $jenis;
	public $tahun_terbit;

//construct : menginisialisasi properti
	function __construct ($pr_nama, $pr_jenis, $pr_tahun_terbit){
		$this->nama = $pr_nama;
		$this->jenis = $pr_jenis;
		$this->tahun_terbit = $pr_tahun_terbit;  
     }
 }

if ($_GET){
	$inputNama = $_GET['inputNama'];
	$inputJenis = $_GET['inputJenis'];
	$inputTahun = $_GET['inputTahunTerbit'];

// $buku1 = new buku ("Harry Potter", "Fiction", "2000")
   $buku1 = new buku ($inputNama, $inputJenis, $inputTahun);

   echo "Data Buku <br>";
   echo "Nama:" . $buku1->nama;
   echo "<br>";
   echo "Genre:" . $buku1->jenis;
   echo "<br>";
   echo "Tahun Terbit:" . $buku1->tahun_terbit;
   echo "<br>";
}


?>