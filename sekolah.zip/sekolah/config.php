<?php

//membuat koneksi ke database
$koneksi=mysqli_connect("localhost", "root", "", "db_sekolah");

//cek kondisi

if (mysqli_connect_errno()) {
	echo "koneksi gagal";
}else{
    echo "koneksi berhasil";
}

?>