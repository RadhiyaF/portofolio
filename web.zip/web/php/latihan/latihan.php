<?php
	$FileKu = “Test.txt”;
	$FileHandle = fopen($FileKu, 'r');
	$Data = fread($FileHandle, 10);
	fclose($FileHandle);
	echo $Data;
?>
