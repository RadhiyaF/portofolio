<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "peserta_didik";
$koneksi = new mysqli($servername, $username, $password, $dbname);
if (!$koneksi){
	die("Koneksi Gagal" . mysqli_connect_error());
}

$sql = "INSERT INTO profil ('NISN', 'nama_peserta', 'ttl', 'alamat', 'jenis_kelamin') values 
('Annisa Maharani', '02-08-2005', 'jl. Bekantan', 'perempuan')";

if (mysqli_query($koneksi, $sql)){
	echo "Tabel Berhasil dibuat";
} else{
	echo "Tabel Gagal dibuat:" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>