<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "peserta_didik";
$koneksi = new mysqli($servername, $username, $password, $dbname);
if (!$koneksi){
	die("Koneksi Gagal" . mysqli_connect_error());
}
$sql = "CREATE TABLE nilai(
id_mapel INT(6) AUTO_INCREMENT PRIMARY KEY,
nama_peserta VARCHAR (30) not null,
nilai_mtk int(5) not null,
nilai_bing int(5) not null,
nilai_bindo int(5) not null)";



if (mysqli_query($koneksi, $sql)){
	echo "Tabel Berhasil dibuat";
} else{
	echo "Tabel Gagal dibuat:" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>