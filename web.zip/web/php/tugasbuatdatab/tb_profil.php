<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "peserta_didik";
$koneksi = new mysqli($servername, $username, $password, $dbname);
if (!$koneksi){
	die("Koneksi Gagal" . mysqli_connect_error());
}
$sql = "CREATE TABLE profil(
NISN INT(6) AUTO_INCREMENT PRIMARY KEY,
nama_peserta VARCHAR (30) not null,
ttl VARCHAR(30) not null,
alamat VARCHAR(30) not null,
jenis_kelamin varchar(15) not null)";


if (mysqli_query($koneksi, $sql)){
	echo "Tabel Berhasil dibuat";
} else{
	echo "Tabel Gagal dibuat:" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>