<?php
$servername = "localhost";
$username = "root";
$password = "";
$koneksi = new mysqli($servername, $username, $password);
if (!$koneksi){
	die("Koneksi Gagal");
}

$buat_db = "CREATE DATABASE peserta_didik";
if ($koneksi->query($buat_db) === TRUE)
{
	echo "Database berhasil dibuat";
} else{
	echo "Database Gagal dibuat";
}
$koneksi->close();
?>