<?php 
echo "<h3>Perulangan for</h3>";
      for ($a=1; $a<=5; $a++){
      	echo "$a";
      } echo "<br><br>";


echo "<h3>Perulangan while</h3>";
$a=1;
     while ($a<5){
     	echo "$a";
     	$a++;
     } echo "<br><br>";


echo "<h3>Perulangan do while</h3>";
$a=1;
do{
	echo "$a";
	$a++;
} while ($a<5);
echo "<br><br>";


echo"<h3>Perulangan foreach</h3>";

$a=array(10,20,30,40,50);
  foreach($a as $value){
  	echo "$value<br>";
  } echo "<br><br>";


echo "<h3>function</h3>";
function tulis(){
  echo "Hello World!";
} tulis(); 
echo "<br><br>";


echo "<h3>Fungsi dengan Argumen</h3>";
function nama($a){
	echo "Hai, $a. <br>";
} 
  nama("Mayaka");
  nama("Radhiya");
  nama("Nara");
  nama("Nazwa");
  nama("Ayu");
  nama("Raisya");
  echo "<br><br>";


echo "<h3>Fungsi dengan 2 Argumen</h3>";
function nama1($a,$b){
	echo "nama : $a, hobi : $b <br>";
} 
   nama1("Arlanda","Nyanyi");
   nama1("Remirza","Masak");
   nama1("Ganisa","Ngoding");
   nama1("Sagas","Renang");
   nama1("Fauzan","Desain Grafis"); echo "<br><br>";


echo"<h3>Fungsi dengan Default Argument</h3>"; 
function nama2($a="Renang"){
	echo "Hobi : $a. <br>";
} 
  nama2("Nyanyi");
  nama2("Masak");
  nama2("Ngoding");
  nama2();
  nama2("Desain Grafis"); 
  echo "<br><br>";


echo "<h3>Fungsi dengan Nilai Kembali</h3>";
function sum ($x,$y){
	$z=$x+$y;
	return $z;
}
  echo "=" . sum(5,10) . "<br>";
  echo "=" . sum(7,13) . "<br>";
  echo "2 + 4 =" . sum(2,4);
?> 


