<?php 
function nama($a){
	echo "Hai, $a. <br>";
} 
  nama("Mayaka");
  nama("Radhiya");
  nama("Nara");
  nama("Nazwa");
  nama("Ayu");
  nama("Raisya");
?>