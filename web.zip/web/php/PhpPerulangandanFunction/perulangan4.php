<?php
//deklarasi array
$siswa = array(
"Nama" => "Raisya",
"Email" => "Raisya@gmail.com",
"Umur" => 16,
"Gender" => "Perempuan"
);

//menampilkan elemen asosiatif melalui foreach loop
foreach ($siswa as $key => $element){
	echo $key . ":" . $element;
	echo "<br>";
}
?>