<?php 
$a=array(10,20,30,40,50);
  foreach($a as $value){
  	echo "$value<br>";
  }
?>