<?php 
function nama($a,$b){
	echo "nama : $a, hobi : $b. <br>";
} 
   nama("Arlanda","Nyanyi");
   nama("Remirza","Masak");
   nama("Ganisa","Ngoding");
   nama("Sagas","Renang");
   nama("Fauzan","Desain Grafis");
?>