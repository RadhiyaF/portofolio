<?php 
function sum ($x,$y){
	$z=$x+$y;
	return $z;
}
  echo "=" . sum(5,10) . "<br>";
  echo "=" . sum(7,13) . "<br>";
  echo "2+4" . sum(2,4);
?>