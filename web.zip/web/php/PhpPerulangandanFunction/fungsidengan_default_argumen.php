<?php 
function nama($a="Renang"){
	echo "Hobi : $a. <br>";
} 
  nama("Nyanyi");
  nama("Masak");
  nama("Ngoding");
  nama();
  nama("Desain Grafis");
?>