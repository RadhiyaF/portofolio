<?php 
function tulis(){
  echo "Hello World!";
} tulis(); echo "<br><br>";
?>