<?php 
      for ($a=1; $a<=5; $a++){
      	echo "$a";
      }
?>
