<?php 
$a=1;
     while ($a<5){
     	echo "$a";
     	$a++;
     }
?>
