<?php 
$a=1;
do{
	echo "$a";
	$a++;
} while ($a<5);
?>