<?php
//echo "<h5>Deret Bilangan Ganjil 0-100<h5>";
//for ($i=0; $i<=100; $i++){
	//if($i%2==1){
		//echo $i . " ";
	//}
//}

echo "<h5>Deret Bilangan Genap 100-0<h5>";
for ($i=100; $i>=0; $i--){
	if($i%2==0){
		echo $i . " ";
	}
}
?>