<?php
echo "<h5> Menampilkan Angka Ganjil dan Genap</h5>";
$i=1;
while ($i<=27) {
	if ($i%2==1) {
		echo "$i = Bilangan Ganjil<br>";
		$i++;
	} else{
		echo "$i = Bilangan Genap<br>";
		$i++;
	}
}


?>

<?php
$i=100;
do{
	echo $i;
	echo " Akan Tampil di Browser";
	$i++;
} while ($i<=10);
?>