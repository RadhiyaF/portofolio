<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "gudang";
$koneksi = new mysqli($servername, $username, $password, $dbname);
if (!$koneksi){
	die("Koneksi Gagal" . mysqli_connect_error());
}
$sql = "CREATE TABLE pegawai(
id_pegawai INT(3) AUTO_INCREMENT PRIMARY KEY,
nama_pegawai VARCHAR (30) not null,
alamat VARCHAR(30) not null,
tahun_masuk INT(4) not null)";

if (mysqli_query($koneksi, $sql)){
	echo "Tabel Berhasil dibuat";
} else{
	echo "Tabel Gagal dibuat:" . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>