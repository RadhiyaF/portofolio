<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Tugas Latihan </title>
</head>
<body>
	<?php 
     $nilai =110;

     if ($nilai  >=85 && $nilai <=100){
     	echo "Nilai yang Anda dapatkan A";
    } else if ($nilai >=75 && $nilai <= 84) {
     	echo "Nilai yang Anda dapatkan B";
    } else if ($nilai >=60 && $nilai <= 74) {
     	echo "Nilai yang Anda dapatkan C";
    } else if ($nilai >=50 && $nilai <= 59) {
     	echo "Nilai yang Anda dapatkan D";
    } else if ($nilai >=0 && $nilai <= 49) {
     	echo "Nilai yang Anda dapatkan E";
    } 
     else  {
     	echo "Nilai tidak valid";
     } 
?>

</body>
</html>