<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Belajar Percabangan 1 Pada PHP ;</title>
</head>
<body>
<?php 
     $nilai = 60;
     if ($nilai >= 90){
     	echo "Nilai yang Anda dapatkan A";
     } else if ($nilai >= 70) {
     	echo "Nilai yang Anda dapatkan B";
     } else{
        echo "Anda belum lulus";
     }

?>
</body>
</html>