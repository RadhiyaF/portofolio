<?php
echo '<h1> Contoh Implementasi Nested-if Statement pada PHP</h1>';
echo '<h2> Mencari Angka Terbesar dari 4 Angka: [AngkaA, AngkaB, AngkaC, AngkaD]</h2>';
$a=31;
$b=12;
$c=90;
$d=56;

if($a>$b){
    if($a>$c){
    	echo '<h2'.$a.'Angka Terbesar!</h2>';
    } else {
    	echo '<h2>'.$d.'Angka Terbesar!</h2>'
    }
} else {
	if($c>$d){
		echo '<h2>'.$c.'Angka Terbesar!</h2>'
	} else {
		echo '<h2>'.$d.'Angka Terbesar!</h2>'
	}
}
} else {
	if($b>$c) {
		if($b>$d) {
			echo '<h2>'.$b.'Angka Terbesar!</h2>'
		} else {
			echo '<h2>'.$d.'Angka Terbesar!</h2>'
		}
	} else{
		if($c>$d){
			echo '<h2>'.$c.'Angka Terbesar!</h2>'
		}
	}
}

?>