let listSiswa = document.getElementsByTagName("ol");
listSiswa[0].addEventListener("click",tampilkan);

function tampilkan(event){
    alert("Cek data siswa"+event.target.innerHTML);
}