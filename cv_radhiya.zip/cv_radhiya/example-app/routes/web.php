<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/cv_radhiya', function () {
    return view('cv_radhiya');
});

Route::get('/siswa', function (){
    return view('smkbpi.siswarpl',
    [
      "siswa01" => "Risa Lestari",
      "siswa02" => "Rudi Hermawan",
      "siswa03" => "Bambang Kusumo",
      "siswa04" => "Lisa Permata",
    ]);
});

// route::get('/siswarpl', function (){
//     return view('smkbpi.siswarpl')->with('siswa05','Risa Lestari');
// });

route::get('/siswarpl', function (){
    $arrSiswa = ["Risa Lestati","Rudi Hermawan","Bambang Kusomo","Lisa Permata"];

    return view('smkbpi/siswarpl')->with('siswa', $arrSiswa);
});

route::get('/nilaisiswa', function (){
    $nama= 'Tya Kirana Putri';
    $nilai= 75;
    return view('smkbpi.nilaisiswa', compact('nama', 'nilai'));
});
