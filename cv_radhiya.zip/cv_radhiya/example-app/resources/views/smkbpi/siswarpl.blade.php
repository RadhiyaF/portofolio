<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar Siswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container text-center mt-4">    
    <h1>Daftar Siswa</h1>
    <ol class="list-group my-4">
        <?php
        foreach ($siswa as $nama) {
        echo "<li class=\"list-group-item\"> $nama </li>";
        }
        ?>

        {{-- <li><?php echo $siswa01; ?></li>
        <li><?php echo $siswa02; ?></li>
        <li><?php echo $siswa03; ?></li>
        <li><?php echo $siswa04; ?></li> 
        <li><?php echo $siswa05; ?></li> --}}
    </ol>
    </div>
   <div class="container text-center mt-4">
    <img class="rounded-circle img-thumbnail m-2" src="/img/stella.jpg" height="100px" width="100px">
    <img class="rounded-circle img-thumbnail m-2" src="/img/bloom.jpg" height="100px" width="100px">
    <img class="rounded-circle img-thumbnail m-2" src="/img/ungu.jpg" height="100px" width="100px">
    </div>
    <div class="container text-center mt-4">
        Copyright &copy; <?php echo date("Y"); ?> Monkiiiii_
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"></script>
</body>
</html>