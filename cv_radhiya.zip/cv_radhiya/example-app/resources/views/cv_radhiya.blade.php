<html>
    <head>
        <link rel="stylesheet" href="cvstyle.css">
    <body>
        <table border="1" align="center" width="1300px" height="900px" cellspacing="0" cellpadding="0">
            <tr>
                <td height="10px"> actor </td>
            </tr>
            <tr>
                <td>
                    <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Radhiya Fitrunnisa</h2><img src="cv.jpg"/>
                </td>
                <td></td> 
            </tr>
                <tr>
                    <td height="20px"> Skill </td>
                </tr>
                <tr>
                    <td height="200px"><p> What I've Learned </p>
                        <ol>
                            <li>html</li>
                            <li>css</li>
                            <li>php</li>
                            <li>c++</li>
                        </ol>
                    </td> 
                </tr>
                <tr>
                     <td height="20px"> Identity </td>
                </tr>
            <tr>
                <td height="200px"><p> My Social Media </p>
                <ol>
                    <li> Instagram: r.ftrns </li></ol></td>
            </tr>
            
    </body>
    </head>
</html>