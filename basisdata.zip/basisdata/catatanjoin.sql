create database db_daerah;
	use db_daerah;
	 create table tb_kota(
	 	id_kota varchar (10) primary key,
	 	id_provinsi varchar (10) not null,
	 	nama_kota varchar (50) not null
	 	);

create table tb_provinsi(
	 	id_provinsi varchar (10) primary key,
	 	nama_provinsi varchar (50) not null
	 	);

 insert into tb_kota values 
	           ('1', '1', 'Jakarta'),
			   ('2', '2', 'Semarang'),
	           ('3', '3', 'Bandung'),
	           ('4', '3', 'Bogor'),
	           ('5', '5', 'Surabaya'),
	           ('6', '6', 'Medan');

	           insert into tb_provinsi values 
	           ('1', 'DKI Jakarta'),
			       ('2', 'Jawa Tengah'),
	           ('3', 'Jawa Barat'),
	           ('4', 'Papua Barat'),
	           ('5', 'Jawa Timur');
);

  select nama_kota, nama_provinsi from tb_kota inner join 
  tb_provinsi on tb_kota.id_provinsi = tb_provinsi.id_provinsi;
	         
	         select * from tb_kota inner join tb_provinsi 
	         on tb_kota.id_provinsi = tb_provinsi.id_provinsi;


	         select * from tb_kota left join 
	         tb_provinsi on tb_kota.id_provinsi = tb_provinsi.id_provinsi;

	         select * from tb_kota right join 
	         tb_provinsi on tb_kota.id_provinsi = tb_provinsi.id_provinsi;

	         select nama_kota from tb_kota FULL OUTER JOIN 	tb_provinsi on tb_kota.nama_kota=