create database sekolah;

	use sekolah;

create table siswaa (
	Nis varchar (6) primary key,
	Nama_siswa varchar (30) not null,
	Alamat varchar (30) not null,
	Jenis_kelamin varchar (2) not null
);

create table guruu (
	Nuptk varchar (6) primary key,
	Nama_guru varchar (30) not null,
	Alamat varchar (30) not null,
	Jenis_kelamin varchar (2) not null,
	No_telp varchar (12) not null
);

create table mata_pelajaran (
	Kd_matpel varchar (5) primary key,
	Nama_matpel varchar (15) not null
);

//masukin data kedalam tabel

insert into siswaa values 
	('1235', 'Indah', 'Jakarta', 'P'),
	('1236', 'Dori', 'Cianjur', 'L'),
	('1237', 'Manu', 'Tasik', 'L'),
	('1238', 'Anis', 'Cimahi', 'P'),
	('1239', 'Bandi', 'Palembang', 'L');

	insert into guruu values 
	('3345', 'Nur', 'Bandung', 'P','0852***'),
	('6543', 'Andy', 'Jakarta', 'L','0852***'),
	('7643', 'Maulana', 'Palu', 'L','0852***'),
	('8663', 'Katrina', 'Lombok', 'P','0852***'),
	('6246', 'Soleh', 'Bandung', 'L','0857***'),
	('9664', 'Siti', 'Palembang', 'P','0852***');

	insert into mata_pelajaran values 
	('a01', 'Matematika'),
	('a02', 'Pkn'),
	('a03', 'Bahasa Indonesia'),
    ('a04', 'Bahasa Ingrris'),
    ('a05', 'Seni Budaya');

//panggil semua isi tabel 
select * from siswaa
select * from guruu
select * from mata_pelajaran

//panggil atribut tertentu
select Nuptk, Nama_guru from guruu

//menampilkan data spesifik
select Nis, Nama_siswa from siswaa where Nis = '1236';
select Nama_matpel from mata_pelajaran where Kd_matpel = 'a01';

//menampilkan klausa where

//menampilkan data yang memiliki huruf khusus
select Nama_siswa from siswaa where Alamat like '%a%';
//tampilkan yang ada huruf  
yg ada huruf %a%
yg ada huruf akhiran %i
yg ada khurud awalan a%



