membuat database = create database sekolahh;

memakai database = use sekolahh;

membuat table = create table matpel (
	skd_matpel varchar (6) primary key,
	nama_matpel varchar (10) not null,
	alamat varchar (30) not null,
	jk varchar(2) not null,
	no_telp int(12) not null
);

mengubah nama table = alter table siswa rename to mahasiswa;

memanggil table = desc mahasiswa;

mengubah table menambahkan kolom = alter table mahasiswa add column kelas varchar (10);

mengubah table mengubah tipe data = alter table mahasiswa modify kelas int(10);

drop table siswa;

//cara langsung
mengisi data = insert into siswa values 
	           ('1235', 'Indah', 'Jakarta', 'P'),
			       ('1236', 'Dori', 'Cianjur', 'L'),
	           ('1237', 'Manu', 'Tasik', 'L'),
	           ('1238', 'Anis', 'Cimahi', 'P'),
	           ('1239', 'Bandi', 'Palembang', 'L');

//cara tidak langsung
mengisi data = insert into siswa (nis, nama, alamat, jk) values ('1234','Reza', 'Bandung', 'L');

//panggil semua isi tabel 
select * from siswaa
select * from guruu
select * from mata_pelajaran

//panggil atribut tertentu
select Nuptk, Nama_guru from guruu

//menampilkan data spesifik
select Nis, Nama_siswa from siswaa where Nis = '1236';
select Nama_matpel from mata_pelajaran where Kd_matpel = 'a01';

//menampilkan klausa where

//menampilkan data yang memiliki huruf khusus
select Nama_siswa from siswaa where Alamat like '%a%';
//tampilkan yang ada huruf  
yg ada huruf %a%
yg ada huruf akhiran %i
yg ada khurud awalan a%

primary key table lain menjadi foreign key = Foreign key (NUPTK) references guru (NUPTK)
contoh = create table matapelajaran (
  Kode_matpel varchar (6) primary key,
  NUPTK varchar (30) not null,
  Nama_matpel varchar (15) not null,
  Foreign key (NUPTK) references guru (NUPTK)
);

select * from nama_tabel order by atribut desc
desc=descending <dari yang terbesar ke yang terkecil>
select * from namaa_tabel order by atribut asc 
asc=ascending   <dari yang terkecil ke yang terbesar>

AGREGASI
1. AVG() = select avg(nama_field) from nama_tabel; //menghitung rata-rata suatu nilai
2. COUNT() = select count(nama_field) from nama_tabel; //menghitung banyaknya suatu data pada satu field
3. MAX() = select max(nama_field) from nama_tabel //mencari nilai maksimal/tertinggi dalam suatu kolom tabel numerik 
4. MIN() = select min(nama_field) from nama_tabel //mencari nilai minimal/terkecil dalam suatu kolom tabel numerik 
5. SUM() = select sum(nama_field) from nama_tabel //menjumlahkan suatu nilai pada kolom nama_tabel
6. ROUND()

//menampilkan rata rata nilai untuk masing-masing mahsiswa
select nilai.NIS, Nama_siswa, avg(Nilai) as rata_rata from siswa, nilai where siswa.NIS = nilai.NIS group by nilai.NIS;
select tabel.atribut, atribut, avg(atribut) as rata_rata from tabel, tabel where tabel.atribut = tabel.atribut group by tabel.atribut;


//menampilkan rata rata nilai untuk masing-masing mahsiswa dari yang terkecil
select nilai.NIS, Nama_siswa, avg(Nilai) as rata_rata from siswa, nilai where siswa.NIS = nilai.NIS group by nilai.NIS order by rata_rata asc;

select nilai.NIS, Nama_siswa, min(Nilai) as nilai tekecil, max(Nilai) as nilai terbesar from siswa, nilai where siswa.NIS = nilai.NIS group by nilai.NIS;

select nilai.NIS, Nama_siswa, 
min(Nilai) as nilai_tekecil,
max(Nilai) as nilai_terbesar
from siswa, nilai
where siswa.NIS = nilai.NIS
group by nilai.NIS;

select sum(Nilai) from nilai;

select nilai.NIS, Nama_siswa, sum(Nilai) as nilai_keseluruhan from siswa, nilai where siswa.NIS = nilai.NIS group by nilai.NIS;
