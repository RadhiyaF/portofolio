///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

DDL (Data Definition Language) = membuat, mengubah, dan menghapus sebuah nama_database
Perintah yang ada dalam DDL =
create table nama_table

alter table nama_table

drop table nama_table

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

DML (Data Manipulation Language) = delete, insert, dan update data dalam sebuah database
Perintah yang ada dalam DML :
Insert
(insert into nama_table values) 
update
delete
select
(select * from nama_table)

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

DCL (Data Control Language) = memberi hak akses pada database tertentu/memberikan password pada database

CREATE USER 'nama-user'@'localhost' IDENTIFIED BY 'password';

DROP USER 'nama_user'@'localhost';

Perintah yang ada dalam DCL:
GRANT hak_akses on nama_database.nama_tabel to 'nama_user'@'localhost'; (pengguna mengakses hak istimewa ke database)

GRANT ALL ON nilai.*TO'nama_user'@'localhost'; (akses penuh)
hak akses = query yg diperbolehkan seperti select, update,insert, select, delete, atau query lainnya

SHOW GRANTS FOR 'nama_user'@'localhost'; (untuk melihat hak akses user)

REVOKE hak_akses ON nama_database.nama_tabel FROM 'nama_user'@'localhost';(mencabut hak akses user)