create database apotek;

	use apotek;

create table pembeli (
	Id_pembeli varchar (6) primary key,
	Nama_pembeli varchar (30) not null,
	Alamat varchar (50) not null,
	Kontak_pembeli varchar (13) not null
);

create table petugas (
	Id_petugas varchar (6) primary key,
	Nama_petugas varchar (30) not null,
	Kontak_petugas varchar (13) not null
);

create table obat (
	Id_obat varchar (6) primary key,
	Nama_obat varchar (30) not null,
	Jenis varchar (30) not null,
	Harga int (15) not null,
	Tanggal_kadaluarsa date not null
); 

create table transaksi (
	Id_transaksi varchar (6) primary key,
	Id_pembeli varchar (30) not null,
	Id_petugas varchar (30) not null,
	Id_obat int (15) not null,
	Jumlah_pesanan varchar (30) not null,
	Tanggal_pemesanan date not null
); 

insert into pembeli values 
	('PG01', 'Burhan', 'Antapani', '082736889187'),
	('PG02', 'Keenan', 'Cibabat', '080988761524'),
	('PG03', 'Anastasya', 'Cibiru', '081982736099'),
	('PG04', 'Farida', 'Cianjur', '089573847287'),
	('PG05', 'Nisa', 'Ciamis', '087348294252');

insert into petugas values 
	('PT01', 'Raka', '082736789187'),
	('PT02', 'Nida', '081435761524'),
	('PT03', 'Firda', '081789736056'),
	('PT04', 'Farhan', '088343525252'),
	('PT05', 'Ridwan', '089937422357');

insert into obat values 
	('OBT01', 'CTM', 'Tablet', '15000', '2022-10-18'),
	('OBT02', 'VIT B1', 'Kapsul', '15000', '2023-03-09'),
	('OBT03', 'VIT B6', 'Kapsul', '22000', '2025-05-30'),
	('OBT04', 'Amoxillin', 'Sirup', '20000', '2025-02-28'),
	('OBT05', 'Ibu Profen', 'Tablet', '15000', '2025-07-05');

 
select * from nama_tabel order by atribut desc
desc=descending <dari yang terbesar ke yang terkecil>
select * from namaa_tabel order by atribut asc 
asc=ascending   <dari yang terkecil ke yang terbesar>

select * from obat order by harga desc;
select * from obat order by Nama_obat asc;