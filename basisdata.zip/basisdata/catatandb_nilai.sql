create database db_nilai;

use db_nilai;

create table siswa (
  NIS varchar (6) primary key,
  Nama_siswa varchar (30) not null,
  Kelas varchar (10) not null
);

create table guru (
  NUPTK varchar (6) primary key,
  Nama_guru varchar (30) not null,
  Alamat varchar (30) not null
);

create table matapelajaran (
  Kode_matpel varchar (6) primary key,
  NUPTK varchar (30) not null,
  Nama_matpel varchar (15) not null,
  Foreign key (NUPTK) references guru (NUPTK)
);

create table nilai (
  Kode_nilai varchar (6) primary key,
  NIS varchar (30) not null,
  Kode_matpel varchar (15) not null,
  Nilai varchar (5) not null,
  Foreign key (NIS) references siswa (NIS),
  Foreign key (Kode_matpel) references matapelajaran (Kode_matpel)
);

insert into siswa values 
	('150130', 'Rahman Abdul', 'XA'),
	('150140', 'Tegar Cahya', 'XB'),
	('150150', 'Atikah', 'XB'),
	('150160', 'Reisya', 'XA');

	insert into guru values 
	('11001', 'Andri Refianto', 'Soreang'),
	('11002', 'Ade Aso', 'Cipageran'),
	('11003', 'M Noor Basuki', 'Baleendah'),
	('11004', 'Agista', 'Gumuruh');

	insert into matapelajaran values 
	('001', '11001', 'PKN'),
	('002', '11002', 'IOT'),
	('003', '11003', 'PBO'),
	('004', '11004', 'ENG');

	insert into nilai values 
	('PKN-1', '150130', '001', '70'),
	('PKN-2', '150140', '001', '80'),
	('PKN-3', '150150', '001', '90'),
	('PKN-4', '150160', '001', '80'),
	('IOT-1', '150130', '002', '80'),
	('IOT-2', '150140', '002', '80'),
	('IOT-3', '150150', '002', '50'),
	('IOT-4', '150160', '002', '60'),
	('PBO-1', '150130', '003', '70'),
	('PBO-2', '150140', '003', '65'),
	('PBO-3', '150150', '003', '75'),
	('PBO-4', '150160', '003', '85'),
	('ENG-1', '150130', '004', '95'),
	('ENG-2', '150140', '004', '85'),
	('ENG-3', '150150', '004', '80'),
	('ENG-4', '150160', '004', '90');

select count(Kode_matpel) from matapelajaran;
select count(Nama_siswa) from siswa;
select count(Nama_guru) from guru;

select Nama_siswa from siswa where Nama_siswa like '%b%';


//menampilkan rata rata nilai untuk masing-masing mahsiswa
select nilai.NIS, Nama_siswa, avg(Nilai) as rata_rata from siswa, nilai where siswa.NIS = nilai.NIS group by nilai.NIS;
select tabel.atribut, atribut, avg(atribut) as rata_rata from tabel, tabel where tabel.atribut = tabel.atribut group by tabel.atribut;
//menampilkan rata rata nilai untuk masing-masing mahsiswa dari yang terkecil
select nilai.NIS, Nama_siswa, avg(Nilai) as rata_rata from siswa, nilai where siswa.NIS = nilai.NIS group by nilai.NIS order by rata_rata asc;

//menampilkan nilai tertentu
select NIS, Nilai, case when nilai >=70 then 'LULUS' else 'TIDAK LULUS' end as predikat from nilai;

select NIS, Nama_siswa, Nilai, case when nilai <=60 then 'REMEDIAL' else 'LULUS' end as keterangan from nilai, siswa;
	